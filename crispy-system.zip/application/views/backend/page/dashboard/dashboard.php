<div class="container-fluid">
    <div class="side-body padding-top">
        <div class="container">
        	<div class="row">
	        	<div class="col-xs-12 col-lg-6">
	        		<h1>Hi Chillax Cafe, Here's what's happening in your store.</h1>
	        	</div>
	        	<div class="col-xs-12 col-lg-6 text-center">
	        		<div class="margin-top-50">
	        			<div class="btn-group btn-group-lg" role="group" aria-label="Large button group">
		        			<button type="button" class="btn btn-default">Today</button>
		        			<button type="button" class="btn btn-default">This Week</button>
		        			<button type="button" class="btn btn-default">This Month</button>
		        		</div>
	        		</div>
	        	</div>
	        </div>
        </div>
        <div class="row">
        	
        </div>
    </div>
</div>